/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectcs;

public class CS {
    
    int shell_sort(int my_arr[]) {
   
       int arr_len = my_arr.length;
       for (int gap = arr_len / 2; gap >0; gap /= 2) {

         for (int i = gap; i < arr_len;i += 1) {
           int temp = my_arr[i];
             int j;
             for (j = i; j >= gap && 
                     my_arr[j - gap] > temp; j -= gap)
                 my_arr[j] = my_arr[j - gap];
                   my_arr[j] = temp; 
         } 
    
} 
       return 0;
    } 

        public static void main(String args[]) {
          
            int my_arr[] = { 12, 34, 54, 2, 3 };
             CS my_instance = new CS();
             
             my_instance.shell_sort(my_arr);
             System.out.println("The array, after performing shell sort is : "); 
                
                  int arr_len = my_arr.length;
                  for (int i = 0; i < arr_len; ++i)
                      System.out.print(my_arr[i] + " ");
                  
                      System.out.println();

        }
}
    
   
       